package com.hcl.bank.service;

public class BenificiaryServiceImpl {

}
