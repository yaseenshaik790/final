
package com.hcl.bank.service;


import com.hcl.bank.dto.BenificiaryDTO;
import com.hcl.bank.dto.BenificiaryRequest;
import com.hcl.bank.exception.BenificiaryNotFoundException;

public interface BenificiaryService {

	public String addBenificiary(BenificiaryRequest benificiaryRequest)throws BenificiaryNotFoundException;

	public String updatedBenificiary(BenificiaryDTO benificiaryRequest) throws BenificiaryNotFoundException;
		
	public String deleteBenificiary(Long benificiaryId) throws BenificiaryNotFoundException;

	public BenificiaryDTO getBenificiaryByBenificiaryId(Long benificiaryId) throws BenificiaryNotFoundException;

		

}
