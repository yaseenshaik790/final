package com.hcl.bank.exception;

public class InsufficientFundException extends Exception {

	private static final long serialVersionUID = 1L;
	private static final Integer STATUS_CODE = 449;

	public InsufficientFundException(String message) {
		super(message);
	}

	public Integer getStatusCode() {
		return STATUS_CODE;
	}

}
